﻿using Microsoft.AspNetCore.Mvc;
using RecipeOrganizerWeb.Models;
using System.Collections.Generic;
using System.Linq;

namespace RecipeOrganizerWeb.Controllers
{
    public class RecipeController : Controller
    {
        private static List<Recipe> recipes = new List<Recipe>();
        private static int nextId = 1;

        public IActionResult Index(string searchTerm)
        {
            var filteredRecipes = string.IsNullOrEmpty(searchTerm)
                ? recipes
                : recipes.Where(r => r.Name.Contains(searchTerm, System.StringComparison.OrdinalIgnoreCase)).ToList();

            return View(filteredRecipes);
        }    
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Recipe recipe)
        {
            if (ModelState.IsValid)
            {
                recipe.Id = nextId++;
                recipes.Add(recipe);
                return RedirectToAction("Index");
            }
            return View(recipe);
        }

        public IActionResult Edit(int id)
        {
            var recipe = recipes.FirstOrDefault(r => r.Id == id);
            if (recipe == null)
            {
                return NotFound();
            }
            return View(recipe);
        }

        [HttpPost]
        public IActionResult Edit(Recipe updatedRecipe)
        {
            if (ModelState.IsValid)
            {
                var recipe = recipes.FirstOrDefault(r => r.Id == updatedRecipe.Id);
                if (recipe == null)
                {
                    return NotFound();
                }

                recipe.Name = updatedRecipe.Name;
                recipe.Ingredients = updatedRecipe.Ingredients;
                recipe.Instructions = updatedRecipe.Instructions;

                return RedirectToAction("Index");
            }
            return View(updatedRecipe);
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            var recipe = recipes.FirstOrDefault(r => r.Id == id);
            if (recipe != null)
            {
                recipes.Remove(recipe);
            }
            return RedirectToAction("Index");
        }
    }
}
